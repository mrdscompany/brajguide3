/* ======= EDIT YOUR DETAILS HERE ======= */
const CONTACT = {
  whatsapp: "918881220050",          // country code + number, no + or spaces
  phoneDisplay: "+91 88812 20050",
  email: "brajguide.com@gmail.com",
  address: "Mathura–Vrindavan, Uttar Pradesh, India",
  defaultMsg: "Hi BrajGuide, I want to plan a Braj yatra. Please share details."
};
/* ===================================== */
const wa = m => `https://wa.me/${CONTACT.whatsapp}?text=${encodeURIComponent(m||CONTACT.defaultMsg)}`;
document.querySelectorAll('.wa-link').forEach(a=>{a.href=wa(a.dataset.msg);a.target="_blank";a.rel="noopener"});
document.querySelectorAll('.call-link').forEach(a=>a.href="tel:+"+CONTACT.whatsapp);
const $=id=>document.getElementById(id);
const setT=(id,t)=>{const e=$(id);if(e)e.textContent=t};
setT('phoneText',CONTACT.phoneDisplay);setT('waText',CONTACT.phoneDisplay);
setT('mailText',CONTACT.email);setT('addrText',CONTACT.address);
setT('yr',new Date().getFullYear());
if($('mailLink'))$('mailLink').href="mailto:"+CONTACT.email;

if($('enq'))$('enq').addEventListener('submit',e=>{
  e.preventDefault();
  const g=id=>document.getElementById(id).value;
  const msg=`Hi BrajGuide!\nName: ${g('fn')}\nPhone: ${g('fp')}\nService: ${g('fs')}\nTravel date: ${g('fd')||'Not decided'}\nDetails: ${g('fm')}`;
  window.open(wa(msg),'_blank');
});

/* header + menu */
const hdr=document.getElementById('hdr'),menu=document.getElementById('menu');
const onScroll=()=>hdr.classList.toggle('scrolled',scrollY>60);addEventListener('scroll',onScroll);onScroll();
document.getElementById('burger').onclick=()=>menu.classList.toggle('open');
menu.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>menu.classList.remove('open')));

/* reveal + counters */
const io=new IntersectionObserver(es=>es.forEach(en=>{
  if(!en.isIntersecting)return;
  en.target.classList.add('in');
  const c=en.target.querySelector('[data-count]');
  if(c&&!c.done){c.done=1;const t=+c.dataset.count;let n=0;const step=Math.max(1,Math.ceil(t/60));
    const iv=setInterval(()=>{n=Math.min(t,n+step);c.textContent=n.toLocaleString()+c.dataset.suffix;if(n>=t)clearInterval(iv)},25)}
  io.unobserve(en.target);
}),{threshold:.15});
document.querySelectorAll('.reveal').forEach(el=>io.observe(el));

/* falling petals */
const p=document.getElementById('petals');const em=['🌸','🌼','🪷','🦚','🌺'];
if(p)for(let i=0;i<14;i++){const s=document.createElement('span');s.textContent=em[i%em.length];
  s.style.left=Math.random()*100+'%';s.style.animationDuration=(9+Math.random()*10)+'s';
  s.style.animationDelay=(-Math.random()*15)+'s';s.style.fontSize=(1+Math.random()*1.2)+'rem';p.appendChild(s)}
